# 1. What is the output of the following code?
# nums =set([1,1,2,3,3,3,4,4])
# print(len(nums))

# Output will be unique numbers = [1,2,3,4] and length will be 4
