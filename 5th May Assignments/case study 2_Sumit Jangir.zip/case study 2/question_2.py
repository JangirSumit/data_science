# 2.What will be the output?
# d ={"john":40, "peter":45}
# print(list(d.keys()))

# It will select all keys of dictionary that is ["john", "peter"]
# So output will dict_keys(['john', 'peter'])
